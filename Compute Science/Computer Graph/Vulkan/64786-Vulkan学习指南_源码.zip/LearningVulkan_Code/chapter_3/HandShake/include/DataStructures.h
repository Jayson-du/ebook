#pragma once

//class VulkanApplication;

/*************LAYER BASED DATA STRUCTURES*************/
/*
* This structure stores the extensions of a given layer.
* A layer can have one or more extensions.
* Use this structure keep track of those extensions here.
*/
//typedef struct {
//	VkLayerProperties properties;
//	std::vector<VkExtensionProperties> extensions;
//} LayerProperties;






















